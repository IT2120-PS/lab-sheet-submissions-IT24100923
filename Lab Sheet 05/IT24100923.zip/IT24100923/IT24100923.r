getwd()
setwd("C:\\Users\\it24100923\\Desktop\\lab 5")
getwd()

Delivery.Times<-read.table("Exercise - lab 05.txt", header = TRUE)
head(Delivery.Times)
hist(Delivery.Times$Delivery, 
     breaks = 9, 
     xlim = c(20,70),
     main = "Histogram of Delivery Time",
     xlab = "Delivery Time", right = TRUE )



delivery_cut <-cut(Delivery.Time$Delivery breaks = seq(20,70, by=5)),right=TRUE)

freq_table<-table(delivery_cut)

cum_freq<-cunsum(freq_table)

bin_midppoint<-seq(22.5,67.5, by=5)

plot(bin_midppoint, cum_freq, type="o",xlab="Delivery Time", ylab="cumulative Frequency",
     main="Cumu;ative Freqency polygon")

delivery_cut <- cut(Delivery.Times$Delivery, breaks=seq(20, 70, by=5), right=TRUE)

freq_table <- table(delivery_cut)

cum_freq <- cumsum(freq_table)

bin_midpoints <- seq(22.5, 67.5, by=5)  

plot(bin_midpoints, cum_freq, type="o", 
     , xlab="Delivery Time", ylab="Cumulative Frequency", 
     main="Cumulative Frequency Polygon (Ogive)")


